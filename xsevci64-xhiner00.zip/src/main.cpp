/*! \file main.cpp
 * \brief Driver code for icp application
 *
 * \author Martin Hiner - xhiner00
 * \author Adam Ševčík - xsevci64
 *
 * \date 17.5.2020
 *
 * \mainpage Bus Line Simulation
 * \section main App Info
 *
 * This application simulates flow of traffic within bus lines.
 * Application is started by selecting time of day and pressing button Start.
 * User is then presented with map of streets. Stops are represented by rectangle icon, buses by circle icon color coded with line's color.
 * At the top of the application window are simulation settings. There, user can see and modify the speed of time, highlight and desplay timetable for bus line and zooom in and out of the map.
 * At the bottom of the application is color legend for each bus line.
 * For simulation purposes, four bus lines are hardcoded to be in simulation.
*/

#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
