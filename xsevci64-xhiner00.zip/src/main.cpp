/*! \file linelib.cpp
 * \brief Driver code for icp application
 *
 * \author Martin Hiner - xhiner00
 * \author Adam Ševčík - xsevci64
 *
 * \date 17.5.2020
 *
 * \mainpage Projekt ICP
 * \section Assignment
 *
 * nech autobusy litaju
*/

#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
