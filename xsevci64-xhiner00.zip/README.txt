Vysoké Učenie Technické Brno
Fakulta informačných technológií

ICP - Seminár C++

Projekt:
	Aplikácia pre zobrazenie liniek hromadnej dopravy a sledovania ich pohybu

Autori:
	Adam Ševčík - xsevci64
	Martin Hiner - xhiner00

Dátum:
	17.5.2020

Poznámky k implementácii:
	Náš projekt nepodporuje definovanie zťaženej dopravnej situácie a uzavretie ulice.
	Tieto vlastnosti sa nám z dôvodu nedostatku času nepodarilo implementovať.
